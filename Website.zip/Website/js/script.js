function searchClub() {
  const query = document.getElementById("searchBar").value.toLowerCase();
  alert(`Searching for: ${query}`);
  // Here, you can implement search functionality by filtering club names or categories
}